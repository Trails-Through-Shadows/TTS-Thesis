# Materials

this is all my materials that ill have or smthng


## webs and so on

spring boot documentation

- https://docs.spring.io/spring-boot/docs/1.1.0.M2/reference/pdf/spring-boot-reference.pdf

rest with spring

- https://www.baeldung.com/rest-with-spring-series

cdn

- https://www.hostinger.com/tutorials/improving-website-performance-using-a-cdn?ppc_campaign=google_search_generic_hosting_all&bidkw=defaultkeyword&lo=1029194&gad_source=1

amazon what is restful api

- https://aws.amazon.com/what-is/restful-api/

what is soap

- https://en.wikipedia.org/wiki/SOAP
- https://www.techtarget.com/searchapparchitecture/definition/SOAP-Simple-Object-Access-Protocol

xml a json

- wikina
- https://www.w3schools.com/xml/xml_whatis.asp
- https://zapier.com/resources/guides/apis/data-formats
- https://www.w3schools.com/xml/
- https://aws.amazon.com/what-is/xml/#:~:text=Extensible%20Markup%20Language%20(XML)%20lets,%2C%20and%20third%2Dparty%20applications. - benefits of xml

graphql

- https://graphql.org/
- https://hygraph.com/learn/graphql
- wikina

## diplomky

- propojení I/O zařízení s webem pomocí Java springboot
  - https://dk.upce.cz/bitstream/handle/10195/81565/AndresK_IntegracePokladni_MB_2023.pdf?sequence=1

- technologie pro vývoj restful api
  - https://rjanda.net/files/RJ-dip.pdf

- technologie jako http json rest graphql a take fajne věci
  - https://dspace.cvut.cz/bitstream/handle/10467/102079/F8-BP-2022-Franklova-Olivie%20Abigail-thesis.pdf?sequence=-1&isAllowed=y







## reálné chyby

- zkontroluj si pak jestli jsou všechny ty výpisy zmíněny v textu
- máš ošklivé tabulky, radši bych to předělala na využití bookmarks a rules
